package functionstruct

type FuncStruct struct {
}

func FAdd(a, b int) int {

	return a + b
}

func FSub(a, b int) int {
	return a - b
}
